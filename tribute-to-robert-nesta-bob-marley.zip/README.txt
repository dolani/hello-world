A Pen created at CodePen.io. You can find this one at http://codepen.io/dolani/pen/yOBwGq.

 A tribute to Robert nesta "bob" marley. 
Thanks to <a href="https://en.wikipedia.org/wiki/Bob_Marley">Wikipedia </a>and <a href="google.com">Google </a>for images.